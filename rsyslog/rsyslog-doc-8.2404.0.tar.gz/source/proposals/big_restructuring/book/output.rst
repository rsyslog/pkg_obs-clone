Output
======

What should be logged
---------------------

Message properties
^^^^^^^^^^^^^^^^^^


System properties
^^^^^^^^^^^^^^^^^


Variables
^^^^^^^^^


Functions
^^^^^^^^^


Transformation Modules
^^^^^^^^^^^^^^^^^^^^^^


When should be logged
---------------------

Filter Conditions
^^^^^^^^^^^^^^^^^

        * “traditional” severity and facility based selectors
        * property-based filters
        * expression-based filters
        * BSD-style blocks (not upward compatible)

Rulesets
^^^^^^^^


How should be logged
--------------------


RainerScript templates
^^^^^^^^^^^^^^^^^^^^^^


Legacy format templates
^^^^^^^^^^^^^^^^^^^^^^^


Properties in templates
^^^^^^^^^^^^^^^^^^^^^^^


Conditionally choosing a template
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


Where should be send: Output Modules
------------------------------------
