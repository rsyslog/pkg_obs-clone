Input: from where come the logs
===============================

