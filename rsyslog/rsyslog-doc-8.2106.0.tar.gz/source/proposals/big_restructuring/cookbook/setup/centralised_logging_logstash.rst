Centralised logging with Logstash/ElasticSearch/Kibana
======================================================

