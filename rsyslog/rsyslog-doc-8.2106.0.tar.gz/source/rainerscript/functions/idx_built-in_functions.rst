******************
Built-in Functions
******************

Following functions are available in Rainerscript.

.. toctree::
   :glob:
   :maxdepth: 1

   ipv42num() <rs-ipv4convert.rst>
   num2ipv4() <rs-ipv4convert.rst>
   ltrim() <rs-trim.rst>
   rtrim() <rs-trim.rst>
   rs*
