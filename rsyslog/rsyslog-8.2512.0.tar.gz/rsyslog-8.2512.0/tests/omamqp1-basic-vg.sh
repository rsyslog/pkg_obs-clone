#!/bin/bash
export USE_VALGRIND="YES"
source ${srcdir:=.}/omamqp1-basic.sh
