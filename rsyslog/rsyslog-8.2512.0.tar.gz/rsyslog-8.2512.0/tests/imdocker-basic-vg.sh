#!/bin/bash
export USE_VALGRIND="YES"
source ${srcdir:-.}/imdocker-basic.sh
