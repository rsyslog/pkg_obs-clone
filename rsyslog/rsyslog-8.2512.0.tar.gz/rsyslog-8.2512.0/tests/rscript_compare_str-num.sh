#!/bin/bash
export LOWER_VAL='"-"'
export HIGHER_VAL='1'
source ${srcdir:-.}/rscript_compare-common.sh
