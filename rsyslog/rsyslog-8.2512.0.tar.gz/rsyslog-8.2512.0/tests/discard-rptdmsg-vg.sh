#!/bin/bash
# This file is part of the rsyslog project, released under ASL 2.0
export USE_VALGRIND="YES"
source ${srcdir:-.}/discard-rptdmsg.sh
