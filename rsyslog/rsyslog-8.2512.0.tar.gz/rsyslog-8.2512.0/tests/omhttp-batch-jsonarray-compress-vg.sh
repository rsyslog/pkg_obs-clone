#!/bin/bash
export USE_VALGRIND="YES"
source ${srcdir:=.}/omhttp-batch-jsonarray-compress.sh
