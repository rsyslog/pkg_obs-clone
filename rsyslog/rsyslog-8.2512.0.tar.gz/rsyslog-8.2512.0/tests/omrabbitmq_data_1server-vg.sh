#!/bin/bash
# add 2019-09-03 by Philippe Duveau, released under ASL 2.0
export USE_VALGRIND="YES"
source ${srcdir:-.}/omrabbitmq_data_1server.sh
