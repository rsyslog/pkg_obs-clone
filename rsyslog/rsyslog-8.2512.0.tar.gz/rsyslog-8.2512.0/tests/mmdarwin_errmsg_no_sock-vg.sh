#!/bin/bash
# add 2019-04-02 by Rainer Gerhards, released under ASL 2.0
export USE_VALGRIND="YES"
source ${srcdir:=.}/mmdarwin_errmsg_no_sock.sh
