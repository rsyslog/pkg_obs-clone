#!/bin/bash
export USE_VALGRIND="YES"
source ${srcdir:-.}/omsendertrack-statefile.sh
