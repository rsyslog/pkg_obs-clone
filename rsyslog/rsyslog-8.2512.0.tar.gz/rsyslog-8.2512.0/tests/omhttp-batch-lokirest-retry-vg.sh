#!/bin/bash
export USE_VALGRIND="YES"
source ${srcdir:=.}/omhttp-batch-kafkarest-retry.sh
