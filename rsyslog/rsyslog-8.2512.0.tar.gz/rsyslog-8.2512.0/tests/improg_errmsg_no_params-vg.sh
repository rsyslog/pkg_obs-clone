#!/bin/bash
# This file is part of the rsyslog project, released under ASL 2.0
export USE_VALGRIND="YES"
source ${srcdir:-.}/improg_errmsg_no_params.sh
