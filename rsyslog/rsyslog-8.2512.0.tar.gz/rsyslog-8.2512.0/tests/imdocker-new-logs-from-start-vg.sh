#!/bin/bash
export USE_VALGRIND="YES"
source ${srcdir:-.}/imdocker-new-logs-from-start.sh
