#!/bin/bash
export USE_VALGRIND="YES"
source ${srcdir:-.}/rscript_number_comparison_LE.sh
