#!/bin/bash
# add 2020-10-02 by Rainer Gerhards, released under ASL 2.0
. ${srcdir:=.}/diag.sh init
generate_conf
add_conf '
template(name="outfmt" type="string" string="%!result%\n")
set $!p1!p2!val="yes!";
if $msg contains "msgnum" then {
	if exists($!p1!p2!val) then
		set $!result = "on";
	else
		set $!result = "off";
	action(type="omfile" file="'$RSYSLOG_OUT_LOG'" template="outfmt")
	}
'
startup
injectmsg 0 1
shutdown_when_empty
wait_shutdown
export EXPECTED='on'
cmp_exact
exit_test
