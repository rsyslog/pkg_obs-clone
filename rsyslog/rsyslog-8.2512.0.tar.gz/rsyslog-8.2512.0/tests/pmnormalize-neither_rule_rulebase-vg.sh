#!/bin/bash
# added 2019-04-10 by Rainer Gerhards, released under ASL 2.0
export USE_VALGRIND="YES"
source ${srcdir:-.}/pmnormalize-neither_rule_rulebase.sh
