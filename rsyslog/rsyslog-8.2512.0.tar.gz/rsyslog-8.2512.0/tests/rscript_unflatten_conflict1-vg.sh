#!/bin/bash
export USE_VALGRIND="YES"
source ${srcdir:-.}/rscript_unflatten_conflict1.sh
