#!/bin/bash
# addd 2019-04-15 by RGerhards, released under ASL 2.0
export USE_VALGRIND="YES"
source ${srcdir:=.}/smtradfile.sh
