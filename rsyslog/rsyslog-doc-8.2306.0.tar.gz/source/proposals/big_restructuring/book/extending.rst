Extending rsyslog
=================

Native plugins
--------------

External plugins
----------------

