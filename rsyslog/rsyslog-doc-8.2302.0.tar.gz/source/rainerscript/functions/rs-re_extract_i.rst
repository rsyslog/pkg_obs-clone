**************
re_extract_i()
**************

Purpose
=======

re_extract_i(expr, re, match, submatch, no-found)

This function is equivalent to `re_extract()` except that
it performs case-insensitive matches. See :doc:`re_extract <rs-re_extract>`
for further details.
