Contributing Code
=================

.. toctree::
    :maxdepth: 2

    standards
    git
